# Generador de Contraseñas Personalizadas

🔐 **Generador de Contraseñas** es una herramienta que permite crear contraseñas seguras y personalizadas según criterios definidos por el usuario. Puedes generar contraseñas con diferentes longitudes, tipos de caracteres y opciones adicionales como evitar caracteres ambiguos.

---

## 🚀 **Instrucciones de Uso**

### 1. **Generar Contraseña en la Web**

Accede al generador en línea desde el siguiente enlace:  
[Generador de Contraseñas Web](https://erick28hdz.github.io/Generador-Contrasenas/)

1. **Configura la longitud** de la contraseña entre 8 y 64 caracteres.
2. **Selecciona los tipos de caracteres** que deseas incluir:
   - **Mayúsculas**: Activar para incluir letras en mayúsculas.
   - **Minúsculas**: Activar para incluir letras en minúsculas.
   - **Números**: Activar para incluir números.
   - **Símbolos**: Activar para incluir símbolos como `@`, `#`, `&`.
3. **Evitar caracteres ambiguos**: Si deseas evitar caracteres como "O" y "0", activa esta opción.
4. Haz clic en **Generar** para obtener la contraseña.
5. **Copia la contraseña** generada haciendo clic en el botón **Copiar**.

---

### 2. **Generar Contraseña desde la Terminal (PC)**

Si prefieres usar la herramienta en tu PC, puedes generar contraseñas directamente desde la terminal utilizando Python. Asegúrate de tener Python instalado. Si no lo tienes, puedes descargarlo desde [python.org](https://www.python.org/).

1. **Descargar el archivo `generador.py`** desde el repositorio.
2. Abre tu terminal o línea de comandos.
3. **Navega a la carpeta donde guardaste `generador.py`.**
4. Ejecuta el siguiente comando para generar una contraseña:
   ```bash
   python generador.py